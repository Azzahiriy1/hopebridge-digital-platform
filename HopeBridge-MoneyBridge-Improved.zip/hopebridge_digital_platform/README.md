# HopeBridge MoneyBridge — Website Prototype

A responsive, bilingual (English/Hausa) static website for Ali Azzahiriy HopeBridge Youth Initiative.

## Included
- Mobile-first technology-inspired design
- About, focus areas, approach and contact/CTA sections
- English/Hausa language toggle
- MoneyBridge demo cashbook: income, expenses, balance, savings target and CSV export
- Local-browser storage only

## Important limitations
This is a demonstration prototype, not a production financial service. MoneyBridge data stays in the visitor's browser on that device and is not synced to HopeBridge or another device. Do not enter passwords, PINs, OTPs, BVN, NIN, bank details or private beneficiary information. There is no user login, server database, administrator dashboard or cloud backup.

## Publish with GitHub Pages
Keep `index.html` at the repository root and preserve the `assets/hopebridge-logo.png` path.
